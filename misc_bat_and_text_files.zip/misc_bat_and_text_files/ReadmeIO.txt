Scott Swift's ESP32 Gpc Printed Circuit Board's I/O Maps For Various PCBs (GPIO numbers):
------------------------------------------------------------------------------------------

Very first board (1) for the 30-pin ESP32 DevKit:
  GPOUT_ONBOARD_LED 2

  GPOUT_SSR1 32
  GPOUT_SSR2 23
  
  GPIN_POT_MODE_SW 34 // ADC1_6 (4)
  
  // Inputs with pulldowns (3-states 00,01,10)
  GPIN_WIFI_AP_SW 18 // (pin 24/30) Set pin to Vcc for WiFi AP mode
  GPIN_WIFI_STA_SW 19 // (pin 25/30) Set pin to Vcc for WiFi STA mode

  GPAIN_POT1 36 // ADC1_0
------------------------------------------------------------------------------------------

Board (2B) for the 30-pin ESP32 DevKit:
  GPOUT_ONBOARD_LED 2 // GPIO38 for ESP32 Board 3B, GPIO02 for ESP32 Board 1 and ESP32 Board 2B
  GPOUT_WIFI_LED 15
  GPOUT_COM_LED 27

  // Solid-state relay outputs
  GPOUT_SSR1 32
  GPOUT_SSR2 23
  
  // Inputs with pulldowns (3-states 00,01,10)
  GPIN_WIFI_AP_SW 21 // Set pin to Vcc for WiFi AP mode
  GPIN_WIFI_STA_SW 19 // Set pin to Vcc for WiFi STA mode

  // Inputs with pulldowns (3-states 00,01,10)
  GPIN_POT_MODE_SW1 18 // Set pin to Vcc for POT1 Mode 1
  GPIN_POT_MODE_SW2 17 // Set pin to Vcc for POT1 Mode 2

  GPAIN_POT1 36 // ADC1_0
------------------------------------------------------------------------------------------

Board (3B) for the 44-pin ESP32 S3 DevKit-1:
  GPOUT_ONBOARD_LED 38
  GPOUT_WIFI_LED 42
  GPOUT_COM_LED 21

  // Solid-state relay outputs
  GPOUT_SSR1 4
  GPOUT_SSR2 6
  
  #if ENABLE_SSR_C_AND_D
    GPOUT_SSR3 17
    GPOUT_SSR4 8
  #endif
  
  // Solid-state relay sense-inputs (no pullup/pulldown)
  GPIN_SSR1 5
  GPIN_SSR2 7

  #if ENABLE_SSR_C_AND_D
    GPIN_SSR3 18
    GPIN_SSR4 9
  #endif

  // Inputs with pulldowns (3-states 00,01,10)
  GPIN_WIFI_AP_SW 40
  GPIN_WIFI_STA_SW 41

  // Inputs with pulldowns (3-states 00,01,10)
  GPIN_POT_MODE_SW1 47
  GPIN_POT_MODE_SW2 39

  GPAIN_POT1 10 // ADC1_9
------------------------------------------------------------------------------------------

Board (2C) for the 30-pin ESP32 DevKit:
  GPOUT_ONBOARD_LED 2
  GPOUT_WIFI_LED 5
  GPOUT_COM_LED 4

  // Solid-state relay outputs
  GPOUT_SSR1 33
  GPOUT_SSR2 32
  
  #if ENABLE_SSR_C_AND_D
    GPOUT_SSR3 25
    GPOUT_SSR4 12
  #endif
  
  // Solid-state relay sense-inputs (no pullup/pulldown)
  GPIN_SSR1 34
  GPIN_SSR2 35
  
  #if ENABLE_SSR_C_AND_D
    GPIN_SSR3 14
    GPIN_SSR4 13
  #endif

  // Inputs with pulldowns (3-states 00,01,10)
  GPIN_WIFI_AP_SW 17
  GPIN_WIFI_STA_SW 18

  // Inputs with pulldowns (3-states 00,01,10)
  GPIN_POT_MODE_SW1 15
  GPIN_POT_MODE_SW2 16

  // Inputs with pulldowns (3-states 00,01,10)
  GPIN_SPARE_MODE_SW1 19
  GPIN_SPARE_MODE_SW2 21

  GPAIN_POT1 36 // ADC1_0
  GPAIN_POT2 39 // ADC1_3
------------------------------------------------------------------------------------------

Board (3C) for the 44-pin ESP32 S3 DevKit-1:
  GPOUT_ONBOARD_LED 38
  GPOUT_WIFI_LED 42
  GPOUT_COM_LED 21

  // Solid-state relay outputs
  GPOUT_SSR1 4
  GPOUT_SSR2 3 // (JTAG strapping pin but should be ok here...)
  
  #if ENABLE_SSR_C_AND_D
    GPOUT_SSR3 17
    GPOUT_SSR4 46 // strapping pin with weak pulldown (should work ok...)
  #endif
  
  // Solid-state relay sense-inputs (no pullup/pulldown)
  GPIN_SSR1 5
  GPIN_SSR2 7
  
  #if ENABLE_SSR_C_AND_D
    GPIN_SSR3 18
    GPIN_SSR4 14
  #endif

  // Inputs with pulldowns (3-states 00,01,10)
  GPIN_WIFI_AP_SW 40 // (pin 24/30) Set pin to Vcc for WiFi AP mode
  GPIN_WIFI_STA_SW 41 // (pin 25/30) Set pin to Vcc for WiFi STA mode

  // Inputs with pulldowns (3-states 00,01,10)
  GPIN_POT_MODE_SW1 47
  GPIN_POT_MODE_SW2 39

  // Inputs with pulldowns (3-states 00,01,10)
  GPIN_SPARE_MODE_SW1 2
  GPIN_SPARE_MODE_SW2 1

  // NOTE: these three pads, together with 3.3V and Ground can be used for
  // a continuously rotating digital encoder control with push-in switch. Or - for 3 POTS...
  GPAIN_POT1 8 // ADC1_7
  GPAIN_POT2 9 // ADC1_8
  GPAIN_POT3 6 // ADC1_5
------------------------------------------------------------------------------------------
