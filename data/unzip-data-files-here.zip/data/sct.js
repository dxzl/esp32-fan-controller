var s_ct, m_min, m_max, m_cs;

String.prototype.escapeSpecialChars = function() {
    return this.replace(/\\n/g, "\\n")
               .replace(/\\'/g, "\\'")
               .replace(/\\"/g, '\\"')
               .replace(/\\&/g, "\\&")
               .replace(/\\r/g, "\\r")
               .replace(/\\t/g, "\\t")
               .replace(/\\b/g, "\\b")
               .replace(/\\f/g, "\\f");
};

function hnEncode(sIn){
  var arr = window.varMaxSct.split(',');
  if (arr.length != 3)
    return "";
  s_ct = parseInt(arr[0]);
  m_max = parseInt(arr[1]);
  m_min = parseInt(arr[2]);
  m_cs = 0;
  var sRet = (s_ct < 10) ? "0" : "";
  sRet += arr[0];
  var charArr = Array.from(sRet + sIn);
  charArr.forEach(arrayProc);
  return (charArr.join('') + String.fromCharCode((~m_cs-1) & 0xffff)).escapeSpecialChars();
}

function arrayProc(v, i, a) {
  let c  = v.charCodeAt(0);
  m_cs += c;
  for (let j = 0; j < s_ct; j++){
      let msbSet = (c & 0x8000) ? true : false;
      c <<= 1;
      c &= 0xffff;
      if (msbSet)
          c |= 1;
  }
  a[i] = String.fromCharCode(c);
  if (--s_ct < m_min)
    s_ct = m_max;
}
