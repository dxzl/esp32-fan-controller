    var s_ct, m_max;
    
    function hnEncode(sIn){
        var arr = window.varMaxSct.split(',');
        if (arr.length != 2)
          return "";
        s_ct = parseInt(arr[0]);
        m_max = parseInt(arr[1]);
        var sRet = (s_ct < 10) ? "0" : "";
        sRet += arr[0];
        var charArr = Array.from(sRet + sIn);
        charArr.forEach(arrayProc);
        return charArr.join('');
    }
    
    function arrayProc(v, i, a) {
        let c  = v.charCodeAt(0);
        for (let j = 0; j < s_ct; j++){
            let msbSet = (c & 0x8000) ? true : false;
            c <<= 1;
            c &= 0xffff;
            if (msbSet)
                c |= 1;
        }
        a[i] = String.fromCharCode(c);
        if (--s_ct <= 0)
          s_ct = m_max;
    }
