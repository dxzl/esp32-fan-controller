$(document).ready(function(){
  setSelectedIndex(document.getElementById("midiChan"),chan);
  let ona = document.getElementById("noteA");
  setSelectedIndex(ona,getNote(na));
  ona.disabled = (na == 128) ? true : false;
  setSelectedIndex(document.getElementById("octA"),getOct(na));
  let onb = document.getElementById("noteB");
  setSelectedIndex(onb,getNote(nb));
  onb.disabled = (nb == 128) ? true : false;
  setSelectedIndex(document.getElementById("octB"),getOct(nb));
  let phaseSlider = document.getElementById("phaseSlider");
  phaseSlider.max = 100;
  phaseSlider.min = 0;
  phaseSlider.value = window.varPhaseVal;
  document.getElementById("phaseVal").innerHTML = (phaseSlider.value == 100) ? "Random" : phaseSlider.value;
  phaseSlider.disabled = true;
  let dcASlider = document.getElementById("dcASlider");
  dcASlider.max = 100;
  dcASlider.min = 0;
  dcASlider.value = window.varDcAVal;
  document.getElementById("dcAVal").innerHTML = (dcASlider.value == 0) ? "Random" : dcASlider.value;
  dcASlider.disabled = true;
  let dcBSlider = document.getElementById("dcBSlider");
  dcBSlider.max = 100;
  dcBSlider.min = 0;
  dcBSlider.value = window.varDcBVal;
  document.getElementById("dcBVal").innerHTML = (dcBSlider.value == 0) ? "Random" : dcBSlider.value;
  dcBSlider.disabled = true;
  function getNote(num){
    // given note index 0-128 return note part
    if (num >= 128)
      return 11; // B

    return (num%12);
  }
  function getOct(num){
    // given note index 0-128 return octave part
    if (num >= 128)
      return 12; // ALL

    return ~~(num/12);
  }
  function setSelectedIndex(s, i){
    let siz = $(s).find('option').length;
    if (siz > 0) {
      if (i >= siz)
        i = siz-1;
      s.options[i].selected = true;
    }
  }
});
document.getElementById("noteA").addEventListener("change", function(){
   let octIdx = document.getElementById("octA").selectedIndex;
   if (octIdx != 12) {
     $.get("/altP1?ehwdo=" + getMidiNote(this.selectedIndex, octIdx), function(data, status){
       if (status == "success" && data != "")
         alert(hnDecode(data));
     });
   }
});
document.getElementById("octA").addEventListener("change", function(){
  $.get("/altP1?ehwdo=" + getMidiNote(processNote(this.selectedIndex, "noteA"), this.selectedIndex), function(data, status){
    if (status == "success" && data != "")
      alert(hnDecode(data));
  });
});
document.getElementById("noteB").addEventListener("change", function(){
  let octIdx = document.getElementById("octB").selectedIndex;
  if (octIdx != 12) {
    $.get("/altP1?fjezm=" + getMidiNote(this.selectedIndex, octIdx), function(data, status){
      if (status == "success" && data != "")
        alert(hnDecode(data));
    });
  }
});
document.getElementById("octB").addEventListener("change", function(){
  $.get("/altP1?fjezm=" + getMidiNote(processNote(this.selectedIndex, "noteB"), this.selectedIndex), function(data, status){
    if (status == "success" && data != "")
      alert(hnDecode(data));
  });
});
document.getElementById("midiChan").addEventListener("change", function(){
  $.get("/altP1?ahejn=" + hnEncNum(this.selectedIndex), function(data, status){
    if (status == "success" && data != "")
      alert(hnDecode(data));
  });
});
phaseSlider.oninput = function(){
  phaseVal.innerHTML = (this.value == 100) ? "Random" : this.value;
}
phaseSlider.onchange = function(){
  Send("/altP1?jeita=", hnEncNum(this.value));
}
dcASlider.oninput = function(){
  dcAVal.innerHTML = (this.value == 0) ? "Random" : this.value;
}
dcASlider.onchange = function(){
  Send("/altP1?neufb=",  hnEncNum(this.value));
}
dcBSlider.oninput = function(){
  dcBVal.innerHTML = (this.value == 0) ? "Random" : this.value;
}
dcBSlider.onchange = function(){
  Send("/altP1?xbmey=", hnEncNum(this.value));
}
function processNote(i, s){
  let o = document.getElementById(s);
  if (i == 12){
    o.disabled = true;
    return 11;
  }
  o.disabled = false;
  return o.selectedIndex;
}
function getMidiNote(note, oct){
  // note 0-11, oct -2(0) to 9(11), ALL (12) (max of G for 9)
  var noteNum;
  if (oct == 12){
    noteNum = 128;
  }
  else {
    noteNum = (12 * oct) + note;
    if (noteNum > 127)
      noteNum = 127;
  }
  return hnEncNum(noteNum);
}
// called from sct.js!
function CheckLock(){
  let ps = document.getElementById("phaseSlider");
  if (window.lockCount == 255){
    if (ps.disabled){
      ps.disabled = false;
      document.getElementById("dcASlider").disabled = false;
      document.getElementById("dcBSlider").disabled = false;
    }
  }
  else if (!ps.disabled){
    ps.disabled = true;
    document.getElementById("dcASlider").disabled = true;
    document.getElementById("dcBSlider").disabled = true;
  }
}
// called from sct.js!
function TimeoutHook(){
}
