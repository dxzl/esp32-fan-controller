var lockCount = 0;
var potVal = 0;
var timeoutTimer = 0;
var wifiSwState = 0;
var potSelSwState = 0;
var intervalId = 0;

String.prototype.escapeb64 = function() {
  return this.replace(/\+/g, '-')
             .replace(/\//g, '_')
             .replace(/\=/g, '');
};

String.prototype.unescapeb64 = function() {
  return this.replace(/\-/g, '+')
             .replace(/\_/g, '/');
};

Base64 = {
  fromNumber : function(number) {
    if (isNaN(Number(number)) || number === null || number === Number.POSITIVE_INFINITY)
      throw "The input is not valid";
    if (number < 0)
      throw "Can't represent negative numbers now";

    var residual = Math.floor(number);
    var result = '';
    while (true) {
      result = window.varB64T.charAt(residual%64) + result;
      residual = Math.floor(residual/64);
      if (residual == 0)
          break;
    }
    return result;
  },

  toNumber : function(rixits) {
    var result = 0;
    rixits = rixits.split('');
    for (let i=0; i<rixits.length; i++)
      result = (result*64) + window.varB64T.indexOf(rixits[i]);
    return result;
  }
}

$(document).ready(function() {
  setTimeout(PollStatus, 10);
  setInterval(PollStatus, 1500);
})


function Send(s, v){
  $.get(s + v, function(data, status){
    if (status == "success"){
      if (data != "")
        alert(hnDecode(data));
    }
  });
}

function PollStatus(){
  $.get("/getHeart?neihs=", function(data, status){
    if (status == "success"){
      let sDec = hnDecode(data);
      if (sDec.length >= 5){
        if (sDec.substr(0,4) == "TXT:"){
          alert(sDec.substr(4));
        }else{
          let arr = sDec.split(',');
          if (arr.length == 4) {
            lockCount = parseInt(arr[0]);
            potVal = parseInt(arr[1]);
            wifiSwState = parseInt(arr[2]);
            potSelSwState = parseInt(arr[3]);
            timeoutTimer = 0;
          }
        }
      }
    }
  });
  if (timeoutTimer < 7){
    if (++timeoutTimer == 6){
      TimeoutHook(); // put a function TimeoutHook in each page that uses sct.js!
      lockCount = 0;
    }
  }
  CheckLock();
}

function twiddle(s){
  l = s.length;
  if (l >= 2){
    if (l & 1){
      s0 = 'e';
      s1 = 'm';
      s2 = 'R';
    }else{
      s0 = 'R';
      s1 = 'e';
      s2 = 'm';
    }
    c1 = s[0];
    c2 = s[1];
    if (c1 == 'c')
      s3 = s0;
    else if (c1 == s0)
      s3 = 'c';
    else if (c1 == 'C')
      s3 = s1;
    else if (c1 == s1)
      s3 = 'C';
    else
      s3 = c1;
    if (c2 == ' ')
      s3 += s2;
    else if (c2 == s2)
      s3 += ' ';
    else
      s3 += c2;
    s3 += s.substring(2);
  }
  else{
    s3 = s;
  }
  return s3;
}

function hnDecode(sIn){
  var sOut = "";
  var arr = atob(sIn.unescapeb64()).split(',');
  if (arr.length < 5)
    return "";
  var sct = Base64.toNumber(arr[0]);
  var sctMin = Base64.toNumber(arr[1]);
  var sctMax = Base64.toNumber(arr[2]);
  var addCs = sct+sctMin+sctMax;
  var cs = Base64.toNumber(arr[arr.length-1]);
  for (let j = 3; j < arr.length-1; j++){
    var n = Base64.toNumber(arr[j]);
    for (let i = 0; i < sct; i++){
      let lsbSet = (n & 1) ? true : false;
      n >>= 1;
      if (lsbSet)
        n |= 0x20000;
    }
    sOut += String.fromCharCode(n);
    addCs += n;
    if (--sct < sctMin)
      sct = sctMax;
  }
  if ((addCs+cs)&0x3fff != 0)
    return "";
  return sOut;
}

function hnEncNum(iIn){
  return hnEncode(Base64.fromNumber(iIn));
}

function hnEncode(sIn){
  var arr = window.varMaxSct.split(',');
  if (arr.length != 3)
    return "";
  var sct = parseInt(arr[0]);
  var sctMin = parseInt(arr[1]);
  var sctMax = parseInt(arr[2]);
  var addCs = sct+sctMin+sctMax;
  var sOut = Base64.fromNumber(sct) + ',' + Base64.fromNumber(sctMin) + ',' + Base64.fromNumber(sctMax) + ',';
  var cArr = Array.from(sIn);
  cArr.forEach(function(ch){
    let n = ch.charCodeAt(0);
    addCs += n;
    for (let j = 0; j < sct; j++){
      let msbSet = (n & 0x20000) ? true : false;
      n <<= 1;
      n &= 0x3ffff;
      if (msbSet)
        n |= 1;
    }
    sOut += Base64.fromNumber(n) + ',';
    if (--sct < sctMin)
      sct = sctMax;
  });
  sOut += Base64.fromNumber((~addCs+1) & 0x3ffff);
  return btoa(sOut).escapeb64();
}
