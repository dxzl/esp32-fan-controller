  var timeFlag=false;

  $(document).ready(function(){
    cbCycleClick(); // init checkbox
    changeSelect();
    setDateTime();

    // set onSubmit handler for p2Form
    var p2F = document.querySelector("#p2Form");
    p2F.onsubmit = p2FormSubmit.bind(p2F);

    function p2FormSubmit(event) {
      event.preventDefault(); // do first in case exception thrown

      let p2Data = new FormData(p2Form);
      var sEnc;

      for(let [name, value] of p2Data) {
        sEnc += "&" + name + "=" + hnEncode(value);
      }

      $.post("/p2Form?" + sEnc, function(data){
        alert(hnDecode(data));
        setTimeout(reloadPage, 500);
      });
    }

    // set listener for data from time-events file
    var fileData = "";
    document.getElementById('fileInput').addEventListener('change', function(){
      var fr=new FileReader();

      fr.onload=function(){
        //document.getElementById('fileOutput').textContent=fr.result;
        fileData = fr.result;
        setTimeout(parseCrLf, 100);
      }
      if (this.files[0].size <= 60*100)
      fr.readAsText(this.files[0]);
    })

    function parseCrLf(){
      let len = fileData.length;
      if (len === 0){
        alert("file is empty!");
      }
      else{
        var sOut = "";
        let sLine = "";
        let evtCount = 0;
        for (i=0; i <= len; i++){
          if (i == len || fileData[i] == '\n'){
            sLine = sLine.trim();
            if (sLine.length > 0 && sLine[0] != '#'){
              evtCount++;
              sOut += sLine + '%'; // Linebreak (Use %0A for GET...)
            }
            sLine = "";
          }
          else if (fileData[i] != '\r' && fileData[i] != '\t')
            sLine += fileData[i];
        }

        if (confirm("Add " + evtCount + " new events?")){
          $.post("/postP2?wqjun=" + hnEncode(sOut), function(data){
            alert(hnDecode(data));
          });
        }
      }
    }

    // this receives date and time of the esp32 every second
    var intervalId = setInterval(getDate,1000);

    function getDate(){
      var sTemp1 = timeFlag ? document.getElementById("setDateTime").value : "0";
      let sTemp2 = "/getP2?gejcc=" + hnEncode(sTemp1);

      $.ajax({
      type:'GET',
      url: sTemp2,
      success: function(data){
        let s = hnDecode(data).split('T');
        if (s.length >= 2) {
          $('#espDate').html(s[0]);
          $('#espTime').html(s[1]);
        }
        for (let ii=2; ii < s.length; ii++){
          let cmd = s[ii];

          if (cmd == "locked"){
            alert("Interface is locked!");
          }
          else if (cmd == "setok"){
            alert("Time was set!");
          }
          else if (cmd == "noset"){
            alert("Failed to set time...");
          }
          else if (cmd == "reload"){
            Connection: close;
            clearInterval(intervalId);
            timeFlag=false;
            setTimeout(reloadPage, 500);
          }
        }
      }
      }).done(function(){
        timeFlag=false;
      })
    }

  });

  // Set current date/time
  function setDateTime(){
    d = new Date();
    let hours = d.getHours();
    let minutes = d.getMinutes();
    let ampm = hours >= 12 ? 1 : 0;
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    $('input[id=myDate]').val(d.getFullYear()+"-"+addZero(d.getMonth() + 1)+"-"+addZero(d.getDate()));
    document.getElementById("hours").selectedIndex = hours-1;
    document.getElementById("minutes").selectedIndex = minutes;
    document.getElementById("pmFlag").selectedIndex = ampm;
  }

  // Set time on remote device to this computer's time
  function getDateTime(){
    if (!timeFlag && confirm("Set time on remote device to this computer's time?")){
      dt = new Date();
      document.getElementById("setDateTime").value=dt.getFullYear() + "-" + addZero(dt.getMonth() + 1)
      + "-" + addZero(dt.getDate()) + "T" + addZero(dt.getHours()) + ":" +
        addZero(dt.getMinutes()) + ":" + addZero(dt.getSeconds());
      document.getElementById("buttonSet").blur(); // fix the button focus
      timeFlag=true;
    }
  }

  function changeSelect(){
    let delItems = document.getElementById("delItems");
    if (delItems.length == 0){
      if (delItems.style.visibility != 'hidden')
        delItems.style.visibility = 'hidden';
    }
    else if (delItems.style.visibility != 'visible'){
      delItems.style.visibility = 'visible';
    }
    if (document.getElementById("buttonEdit").value == "OK"){
      $('#buttonEdit').val('Edit');
      $('p2Form')[0].reset();
    }
  }

  document.getElementById("getFile").onclick = function(){
      document.getElementById("fileInput").click();
      document.getElementById("getFile").blur(); // fix the button focus
  };

  $('input[type=file]').change(function (e){
      $('#customfileupload').html($(this).val());
  });

  function cbCycleClick(){
    document.getElementById("cbRepeats").disabled = !document.getElementById("cbCycle").checked;
  }

  // send replaceIndex to effect replacement - do p2Form submit via
  // javascript replacing value in hidden param replaceIndex
  function editItem(){
    if (document.getElementById("buttonEdit").value == "OK"){
      if (document.getElementById("cbCycle").checked){
        let useOld = 0;
        if (document.getElementById("useOldTimeVals").value == 1){
          if (confirm("Yes overwrites with new cycle-timing. Cancel will keep old cycle-timing.")){
            useOld = 1;
          }
        }
        $('#useOldTimeVals').val(useOld);
      }
      $('#p2Form').submit();
      $('#buttonEdit').val('Edit');
    }else{
      let editItems = document.getElementById("delItems");
      $.get("/getP2?ejddo=" + hnEncNum(editItems.selectedIndex), function(data, status){
        if (status == "success"){
          var vars = hnDecode(data).split(',');
          if (vars.length == 22){
            document.getElementById("repeatMode").options.selectedIndex = vars[0];
            document.getElementById("deviceMode").options.selectedIndex = vars[1];
            document.getElementById("deviceAddr").options.selectedIndex = vars[2];
            $('#repeatCount').val(vars[3]);
            $('#everyCount').val(vars[4]);
            //document.getElementById("dayOfWeek").options.selectedIndex = vars[5];
            document.getElementById("hours").options.selectedIndex = vars[6]-1;
            document.getElementById("minutes").options.selectedIndex = vars[7];
            document.getElementById("seconds").options.selectedIndex = vars[8];
            $('input[id=myDate]').val(vars[11]+'-'+addZero(vars[10])+'-'+addZero(vars[9]));
            document.getElementById("pmFlag").options.selectedIndex = vars[12];
            // 13-17 are cycle-timing info
            var haveOld;
            if(vars[13] != -1 || vars[14] != -1 || vars[15] != -1 || vars[16] != -1 || vars[17] != -1)
              haveOld = 1;
            else
              haveOld = 0;
            $('#useOldTimeVals').val(haveOld);
            document.getElementById("cbCycle").checked = (vars[18] == 1) ? true : false;
            document.getElementById("cbRepeats").disabled = false;
            document.getElementById("cbRepeats").checked = (vars[19] == 1) ? true : false;
            //$('#enabled').val(vars[20]);
            $('#replaceIndex').val(vars[21]);
            $('#buttonEdit').val('OK');
            $('p2Form')[0].reset();
          }
        }
      });
    }
    {Connection: close};
  }

  function eraseItems(){
    if (confirm("Erase all time-events?")){
      var sErEnc = "K7w5V";
      $.get("/getP2?lkeism=" + hnEncode(sErEnc), function(data, status){
        alert(hnDecode(data));
        if (status == "success")
          setTimeout(reloadPage, 500);
      });
      {Connection: close};
    }
  }

  function delItem(){
    $.get("/getP2?heifq=" + hnEncNum(document.getElementById("delItems").value), function(data, status){
      alert(hnDecode(data));
      if (status == "success")
        setTimeout(reloadPage, 500);
    });
    {Connection: close};
  }

  // save list of items in select widget to downloads folder
  function saveItems(sName){
    let newName = "";
    for (let i = 0; i < sName.length; i++){
      if (sName[i] == '.')
        break;
      newName += sName[i];
      if (newName.length >= 7)
        break;
    }
    if (newName.length == 0)
      newName = "myEvent";
    newName += ".txt";

    let select = document.getElementById("delItems");
    let len = select.options.length;
    if(len > 0){
      var s = "#100 time-events maximum allowed!\n" +
      "#Format example: (* if event expired)\n" +
      "# 12/31/2020, 12:59:59pm, AB:auto r:65534, e:65534,t:min\n" +
      "# (am, pm), (A, B, AB), (off, on, auto)\n" +
      "# (off/sec/min/hrs/day/wek/mon/yrs)\n" +
      "# (optional cycle-timing: a:40,b:50,p:20,u:0-3,m:0-9,v:0-100,\n" +
      "# i:y include cycle-timing, c:y ...in repeat events)\n";
      for(let i=0; i<len; i++) {
        s += select.options[i].text;
        if (i<len-1)
          s += "\n";
      }
      // start file download.
      download(newName, s);
    }
    else{
      window.alert("No events to save!");
    }
  }

  // make a file to download
  function download(filename, txt){
    let element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(txt));
    element.setAttribute('download', filename);

    element.style.display = 'none';
    document.body.appendChild(element);

    element.click();

    document.body.removeChild(element);
  }

  function addZero(n){
    return (n <= 9) ? "0" + n : n;
  }

  // called from setTimeout()
  function reloadPage(){
    location.href=document.URL;
  }

  // called from sct.js!
  function CheckLock(){
  }
  // called from sct.js!
  function TimeoutHook(){
  }
