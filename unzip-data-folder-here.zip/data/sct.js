var s_ct, m_min, m_max, m_cs;
var lockCount = 0;
var potVal = 0;
var timeoutTimer = 0;
var wifiSwState = 0;
var potSelSwState = 0;
var intervalId = 0;

String.prototype.escapeSpecialChars = function() {
    return this.replace(/\\n/g, "\\n")
               .replace(/\\'/g, "\\'")
               .replace(/\\&/g, "\\&")
               .replace(/\\r/g, "\\r")
               .replace(/\\t/g, "\\t")
               .replace(/\\b/g, "\\b")
               .replace(/\\f/g, "\\f")
               .replace(/\\([\s\S])|(")/g,"\\$1$2");
};

$(document).ready(function() {
  setTimeout(PollStatus, 10);
  setInterval(PollStatus, 1500);
})

function PollStatus(){
  $.get("/getHeart?jdwoddlsxh=", function(data, status){
      let arr = data.split(',');
      if (arr.length == 4) {
        window.lockCount = parseInt(arr[0]);
        window.potVal = parseInt(arr[1]);
        window.wifiSwState = parseInt(arr[2]);
        window.potSelSwState = parseInt(arr[3]);
        window.timeoutTimer = 0;
      }
  });
  if (window.timeoutTimer < 7){
    if (++window.timeoutTimer == 6){
      TimeoutHook(); // put a function TimeoutHook in each page that uses sct.js!
      window.lockCount = 0;
    }
  }
  CheckLock();
}

function hnEncode(sIn){
  var arr = window.varMaxSct.split(',');
  if (arr.length != 3)
    return "";
  s_ct = parseInt(arr[0]);
  m_max = parseInt(arr[1]);
  m_min = parseInt(arr[2]);
  m_cs = 0;
  var sRet = (s_ct < 10) ? "0" : "";
  sRet += arr[0];
  var charArr = Array.from(sRet + sIn);
  charArr.forEach(arrayProc);
  return (charArr.join('') + String.fromCharCode((~m_cs+1) & 0xffff)).escapeSpecialChars();
}

function arrayProc(v, i, a) {
  let c  = v.charCodeAt(0);
  m_cs += c;
  for (let j = 0; j < s_ct; j++){
      let msbSet = (c & 0x8000) ? true : false;
      c <<= 1;
      c &= 0xffff;
      if (msbSet)
          c |= 1;
  }
  a[i] = String.fromCharCode(c);
  if (--s_ct < m_min)
    s_ct = m_max;
}
