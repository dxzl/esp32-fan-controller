var ledStyle = "margin: 20px auto;width: 10px; height: 10px;border-radius: 50%;";
var ledTimer = 0;
$(document).ready(function(){
  document.getElementById('labelTxtA').addEventListener('blur', function(){
    SendRxJson("/getIndex?wjdte=", hnEncode(this.innerText));
  });
  document.getElementById('labelTxtB').addEventListener('blur', function(){
    SendRxJson("/getIndex?meufw=", hnEncode(this.innerText));
  });
  /*
  document.getElementById('labelTxtC').addEventListener('blur', function(){
    SendRxJson("/getIndex?keinj=", hnEncode(this.innerText));
  });
  document.getElementById('labelTxtD').addEventListener('blur', function(){
    SendRxJson("/getIndex?jyolx=", hnEncode(this.innerText));
  });
  */
  $('div[contenteditable]').keydown(function(e) {
    if (e.keyCode === 13) {
      document.execCommand('insertHTML', false, '<br/>');
      return false;
    }
  });
  document.getElementById("perMax").value = window.varPerMax;
  document.getElementById("perUnits").selectedIndex = window.varPerUnits;
  let vPerSlider = document.getElementById("perSlider");
  vPerSlider.max = 100;
  vPerSlider.min = 0;
  vPerSlider.value = window.varPerVal;
  vPerSlider.disabled = true;
  DispMax();
  DispVal();
  DispUnits();
  setInterval(GetState, 1000);
  setInterval(GetText, 2500);
})
$("#hnForm").submit(function(e){
  e.preventDefault();
  SendRxJson("/getIndex?hddsi=", hnEncode(twiddle(document.getElementById("hostName").value)));
});
var butClk = function(but){
  if (but.length == 2){
    var arr = window.varMaxSct.split(',');
    if (arr.length == 3)
      document.getElementById(but).href= "/getBut?" + but[0] + '=' + hnEncode(but[1] + arr[0]);
  }
}
perSlider.oninput = function(){
  DispVal();
}
perSlider.onchange = function(){
  Send("/getIndex?rrksv=", hnEncNum(this.value));
}
perMax.oninput = function(){
  DispMax();
  DispVal();
}
perMax.onchange = function (){
  Send("/getIndex?geuge=", hnEncNum(this.value));
}
perUnits.oninput = function(){
  DispUnits();
}
perUnits.onchange = function (){
  Send("/getIndex?djeuc=", hnEncNum(this.value));
}
function DispMax(){
  let vPerS = document.getElementById("perSlider");
  let vPerM = document.getElementById("perMax");
  document.getElementById("spanPerMax").innerHTML = GetPeriod(vPerS.max, vPerM.value);
}
function DispVal(){
  let vPerS = document.getElementById("perSlider");
  let vPerM = document.getElementById("perMax");
  document.getElementById("spanPerVal").innerHTML = GetPeriod(vPerS.value, vPerM.value);
}
function DispUnits(){
  let vPerU = document.getElementById("perUnits");
  document.getElementById("spanPerUnits").innerHTML = vPerU.options[vPerU.selectedIndex].text;
}
function GetPeriod(val, maxVal){
  return (val == 0) ? "Random" : Math.trunc(val*maxVal/100.0);
}
function GetState(){
  GetS("/getIndex?mwial=" + hnEncode("F2jB"),"ledA","stateTxtA");
  GetS("/getIndex?uvohh=" + hnEncode("iV2m"),"ledB","stateTxtB");
  /*
  GetS("/getIndex?bseor=" + hnEncode("HwOI"),"ledC","stateTxtC");
  GetS("/getIndex?lewap=" + hnEncode("mPsE"),"ledD","stateTxtD");
  */
}
function GetText(){
  $.get("/getIndex?ifhrv=" + hnEncode("u7Za"), function(data, status){
    if (status == "success" && data != "")
      document.getElementById("stateTxtA").innerHTML = hnDecode(data);
  });
}
function SendRxJson(s, v){
  $.get(s + v, function(data, status){
    if (status == "success" && data != ""){
      let dec = hnDecode(data);
      if (dec != "")
        setTimeout(function(){MyEval(dec);},1000);
    }  
  });
}
function MyEval(val){
  var jo = JSON.parse(val);
  if (jo.a != "")
    alert(jo.a);
  if (jo.l != "")
    location.href = jo.l;
  if (jo.o != "")
    window.open(jo.o, "_self");
}
function GetS(r,l,s){
  $.get(r, function(data, status){
    let arr = hnDecode(data).split(',');
    if (arr.length == 4) {
      setLed(l, arr[0]);
      let sTemp = "Mode: " + arr[1];
      if (arr[1] == "AUTO"){
        let sUnits = "sec";
        let iTime = arr[2]/2.0;
        if (iTime >= 60){
          sUnits = "min";
          iTime /= 60.0;
          if (iTime >= 60.0){
            sUnits = "hrs";
            iTime /= 60.0;
            if (iTime >= 24.0){
              sUnits = "days";
              iTime /= 24.0;
            }
          }
        }
        let sNextOnOff = (arr[0] == "ON") ? "off" : "on";
        let lTime = (sUnits == "sec") ? iTime.toFixed(0) : iTime.toFixed(1);
        sTemp += ", " + arr[3] + "&percnt; on, " + sNextOnOff + " in " + lTime + " " + sUnits;
      }
      document.getElementById(s).innerHTML = sTemp;
    }
  });
}
// called from sct.js!
function CheckLock(){
  let pm = document.getElementById("perMax");
  if (window.lockCount == 255){
    if (pm.disabled){
      pm.disabled = false;
      document.getElementById("perUnits").disabled = false;
      document.getElementById("perSlider").disabled = false;
      document.getElementById("labelTxtA").contentEditable = true;
      document.getElementById("labelTxtB").contentEditable = true;
      /*
      document.getElementById("labelTxtC").contentEditable = true;
      document.getElementById("labelTxtD").contentEditable = true;
      */
    }
  }
  else if (!pm.disabled){
    pm.disabled = true;
    document.getElementById("perUnits").disabled = true;
    document.getElementById("perSlider").disabled = true;
    document.getElementById("labelTxtA").contentEditable = false;
    document.getElementById("labelTxtB").contentEditable = false;
    /*
    document.getElementById("labelTxtC").contentEditable = false;
    document.getElementById("labelTxtD").contentEditable = false;
    */
  }
}
// called from sct.js!
function TimeoutHook(){
  let s = ledStyle + "background-color: #F00; box-shadow: #000 0 -1px 6px 1px, inset #600 0 -1px 8px, #F00 0 3px 11px;";
  document.getElementById("ledA").style = s;
  document.getElementById("ledB").style = s;
  /*
  document.getElementById("ledC").style = s;
  document.getElementById("ledD").style = s;
  */
}
function setLed(sLed, sState){
  let led = document.getElementById(sLed);
  if (sState == "ON")
    led.style = ledStyle + "background-color: #0F0; box-shadow: #000 0 -1px 6px 1px, inset #060 0 -1px 8px, #0F0 0 3px 11px;";
  else
    led.style = ledStyle + "background-color: rgba(255, 255, 255, 0.25); box-shadow: #000 0 -1px 6px 1px;";
}
