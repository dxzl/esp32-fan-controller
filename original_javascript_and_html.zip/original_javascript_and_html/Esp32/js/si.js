function sub(obj){
  var fileName = obj.value.split('/').pop();
  var idx1 = fileName.lastIndexOf('\\');
  var idx2 = fileName.lastIndexOf('/');

  /* Remove the extra delimiter by skipping it */
  var len = fileName.length;
  if (idx1 >= 0)
    fileName = fileName.substring(idx1+1, len);
  else if (idx2 >= 0)
    fileName = fileName.substring(idx2+1, len);

  document.getElementById("file-input").innerHTML = "   " + fileName;
};

$("form").submit(function(e){
  e.preventDefault();
  var form = $("#upload_form")[0];
  var data = new FormData(form);
  $.ajax(
    {
      url: "/update",
      type: "POST",
      data: data,
      contentType: false,
      processData:false,
      xhr: function(){

      var xhr = new window.XMLHttpRequest();

      xhr.upload.addEventListener("progress", function(evt){
        if (evt.lengthComputable){
          var per = Math.round((evt.loaded/evt.total)*100);
          var sMsg;
          if (per < 100)
            sMsg = "progress: " + per + "%";
          else
            sMsg = "finishing up...";
          $("#prg").html(sMsg);
        }
      }, false);

      return xhr;
    },
    success:function(d, s){
      $("#prg").html("rebooting and reconnecting, please wait...");
      setTimeout(function (){
        window.location.href = "index.html";
      }, 12000);
    },
    error: function (a, b, c){
      alert("update failed!");
    }
  });
});
