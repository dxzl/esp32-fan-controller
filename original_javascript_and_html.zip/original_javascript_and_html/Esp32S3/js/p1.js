$(document).ready(function(){
  setSelectedIndex(document.getElementById("midiChan"),chan);
  let ona = document.getElementById("noteA");
  setSelectedIndex(ona,getNote(na));
  ona.disabled = (na == 128) ? true : false;
  setSelectedIndex(document.getElementById("octA"),getOct(na));
  let onb = document.getElementById("noteB");
  setSelectedIndex(onb,getNote(nb));
  onb.disabled = (nb == 128) ? true : false;
  setSelectedIndex(document.getElementById("octB"),getOct(nb));
  /* */
  let onc = document.getElementById("noteC");
  setSelectedIndex(onc,getNote(nc));
  onc.disabled = (nc == 128) ? true : false;
  setSelectedIndex(document.getElementById("octC"),getOct(nc));
  let ond = document.getElementById("noteD");
  setSelectedIndex(ond,getNote(nd));
  ond.disabled = (nd == 128) ? true : false;
  setSelectedIndex(document.getElementById("octD"),getOct(nd));
  /* */
  let phaseBSlider = document.getElementById("phaseBSlider");
  phaseBSlider.max = 100;
  phaseBSlider.min = 0;
  phaseBSlider.value = window.varPhaseBVal;
  document.getElementById("phaseBVal").innerHTML = (phaseBSlider.value == 100) ? "Random" : phaseBSlider.value;
  phaseBSlider.disabled = true;
  /* */
  let phaseCSlider = document.getElementById("phaseCSlider");
  phaseCSlider.max = 100;
  phaseCSlider.min = 0;
  phaseCSlider.value = window.varPhaseCVal;
  document.getElementById("phaseCVal").innerHTML = (phaseCSlider.value == 100) ? "Random" : phaseCSlider.value;
  phaseCSlider.disabled = true;
  let phaseDSlider = document.getElementById("phaseDSlider");
  phaseDSlider.max = 100;
  phaseDSlider.min = 0;
  phaseDSlider.value = window.varPhaseDVal;
  document.getElementById("phaseDVal").innerHTML = (phaseDSlider.value == 100) ? "Random" : phaseDSlider.value;
  phaseDSlider.disabled = true;
  /* */
  let dcASlider = document.getElementById("dcASlider");
  dcASlider.max = 100;
  dcASlider.min = 0;
  dcASlider.value = window.varDcAVal;
  document.getElementById("dcAVal").innerHTML = (dcASlider.value == 0) ? "Random" : dcASlider.value;
  dcASlider.disabled = true;
  let dcBSlider = document.getElementById("dcBSlider");
  dcBSlider.max = 100;
  dcBSlider.min = 0;
  dcBSlider.value = window.varDcBVal;
  document.getElementById("dcBVal").innerHTML = (dcBSlider.value == 0) ? "Random" : dcBSlider.value;
  dcBSlider.disabled = true;
  /* */
  let dcCSlider = document.getElementById("dcCSlider");
  dcCSlider.max = 100;
  dcCSlider.min = 0;
  dcCSlider.value = window.varDcCVal;
  document.getElementById("dcCVal").innerHTML = (dcCSlider.value == 0) ? "Random" : dcCSlider.value;
  dcCSlider.disabled = true;
  let dcDSlider = document.getElementById("dcDSlider");
  dcDSlider.max = 100;
  dcDSlider.min = 0;
  dcDSlider.value = window.varDcDVal;
  document.getElementById("dcDVal").innerHTML = (dcDSlider.value == 0) ? "Random" : dcDSlider.value;
  dcDSlider.disabled = true;
  /* */
  function getNote(num){
    // given note index 0-128 return note part
    if (num >= 128)
      return 11; // B

    return (num%12);
  }
  function getOct(num){
    // given note index 0-128 return octave part
    if (num >= 128)
      return 12; // ALL

    return ~~(num/12);
  }
  function setSelectedIndex(s, i){
    let siz = $(s).find('option').length;
    if (siz > 0) {
      if (i >= siz)
        i = siz-1;
      s.options[i].selected = true;
    }
  }
});
document.getElementById("noteA").addEventListener("change", function(){
  doOct("ehwdo", "octA");
});
document.getElementById("noteB").addEventListener("change", function(){
  doOct("fjezm", "octB");
});
/* */
document.getElementById("noteC").addEventListener("change", function(){
  doOct("yrpma", "octC");
});
document.getElementById("noteD").addEventListener("change", function(){
  doOct("keiwh", "octD");
});
/* */
function doOct(c, o){
 let octIdx = document.getElementById(o).selectedIndex;
 if (octIdx != 12) {
   $.get("/altP1?" + c + "=" + getMidiNote(this.selectedIndex, octIdx), function(data, status){
     if (status == "success" && data != "")
       alert(hnDecode(data));
   });
 }
}
document.getElementById("octA").addEventListener("change", function(){
  doNote("ehwdo", "noteA");
});
document.getElementById("octB").addEventListener("change", function(){
  doNote("fjezm", "noteB");
});
/* */
document.getElementById("octC").addEventListener("change", function(){
  doNote("yrpma", "noteC");
});
document.getElementById("octD").addEventListener("change", function(){
  doNote("keiwh", "noteD");
});
/* */
function doNote(c, o){
  let i = this.selectedIndex;
  $.get("/altP1?" + c + "=" + getMidiNote(processNote(i, o), i), function(data, status){
    if (status == "success" && data != "")
      alert(hnDecode(data));
  });
}
document.getElementById("midiChan").addEventListener("change", function(){
  $.get("/altP1?ahejn=" + hnEncNum(this.selectedIndex), function(data, status){
    if (status == "success" && data != "")
      alert(hnDecode(data));
  });
});
phaseBSlider.oninput = function(){
  phaseBVal.innerHTML = (this.value == 100) ? "Random" : this.value;
}
phaseBSlider.onchange = function(){
  Send("/altP1?jeita=", hnEncNum(this.value));
}
/* */
phaseCSlider.oninput = function(){
  phaseCVal.innerHTML = (this.value == 100) ? "Random" : this.value;
}
phaseCSlider.onchange = function(){
  Send("/altP1?aimrs=", hnEncNum(this.value));
}
phaseDSlider.oninput = function(){
  phaseDVal.innerHTML = (this.value == 100) ? "Random" : this.value;
}
phaseDSlider.onchange = function(){
  Send("/altP1?kepuw=", hnEncNum(this.value));
}
/* */
dcASlider.oninput = function(){
  dcAVal.innerHTML = (this.value == 0) ? "Random" : this.value;
}
dcASlider.onchange = function(){
  Send("/altP1?neufb=",  hnEncNum(this.value));
}
dcBSlider.oninput = function(){
  dcBVal.innerHTML = (this.value == 0) ? "Random" : this.value;
}
dcBSlider.onchange = function(){
  Send("/altP1?xbmey=", hnEncNum(this.value));
}
/* */
dcCSlider.oninput = function(){
  dcCVal.innerHTML = (this.value == 0) ? "Random" : this.value;
}
dcCSlider.onchange = function(){
  Send("/altP1?wovrj=", hnEncNum(this.value));
}
dcDSlider.oninput = function(){
  dcDVal.innerHTML = (this.value == 0) ? "Random" : this.value;
}
dcDSlider.onchange = function(){
  Send("/altP1?lrone=", hnEncNum(this.value));
}
/* */
function processNote(i, s){
  let o = document.getElementById(s);
  if (i == 12){
    o.disabled = true;
    return 11;
  }
  o.disabled = false;
  return o.selectedIndex;
}
function getMidiNote(note, oct){
  // note 0-11, oct -2(0) to 9(11), ALL (12) (max of G for 9)
  var noteNum;
  if (oct == 12){
    noteNum = 128;
  }
  else {
    noteNum = (12 * oct) + note;
    if (noteNum > 127)
      noteNum = 127;
  }
  return hnEncNum(noteNum);
}
// called from sct.js!
function CheckLock(){
  let ps = document.getElementById("phaseBSlider");
  if (window.lockCount == 255){
    if (ps.disabled){
      ps.disabled = false;
      document.getElementById("dcASlider").disabled = false;
      document.getElementById("dcBSlider").disabled = false;
      /* */
      document.getElementById("dcCSlider").disabled = false;
      document.getElementById("dcDSlider").disabled = false;
      /* */
    }
  }
  else if (!ps.disabled){
    ps.disabled = true;
    document.getElementById("dcASlider").disabled = true;
    document.getElementById("dcBSlider").disabled = true;
    /* */
    document.getElementById("dcCSlider").disabled = true;
    document.getElementById("dcDSlider").disabled = true;
    /* */
  }
}
// called from sct.js!
function TimeoutHook(){
}
