NOTE: 6/5/2023 For Arduino IDE 1.x, need to add this line to prererences.txt: build.path=G:\Documents\Arduino\projects\Output
(where you put the correct path where you want the build output).
preferences.txt is in folder C:\Users\somebody\AppData\Local\Arduino15

I don't use the "Sketch->Export compiled Binary" menu item anymore. Instead, do "Sketch->Upload". Then the bin files will be
in the Output folder described above. Then you can use pgm.bat to flash the main .bin file. Use "Tools->ESP32 Sketch Data Upload" to
upload the fcspiffs.bin file (data partition) from the spiffs folder. Build fcspiffs.bin by running fcspiffs.bat. When you update
the main ESP32 board tools, you need to change the revision in pgm.bat

For example, the 2.0.9 may change... "%MyEsp%\hardware\esp32\2.0.9\tools\partitions\boot_app0.bin"

"Tools->ESP32 Sketch Data Upload" won't appear in the Tools menu unless you create directory G:\Documents\Arduino\tools and copy
the unzipped folder and file "ESP32FS\tool\esp32fs.jar" into it.

For over-the-air software update type "c update" or "c upload" into the web-page's hostname edit-box then select either
the fc.bin program file (created by selecting "Sketch->Export Compiled Binary" and then running fixname.bat) or the fcspiffs.bin
web-data file in the spiffs folder (created by running fcspiffs.bat)
 
NOTE: everything works ok with the Arduino 2.X IDE except that there is no plugin written
that supports "Sketch Data Upload", which is supported in 1.X. And - that's a show-stopper for me.
In 2.X, a "build" directory is created. To use 2.X, modify the pgm.bat file - see comments in that file.

First generate main .bin file from Arduino 1.X IDE: "Sketch->Export Compiled Binary"
double-click fixname.bat to rename to fc.bin
then go into spiffs and double-click fcspiffs.bat to genetate fc.spiffs.bin

start the fan-controller and go to its web page "http://dts7.local or http://dts10.local", Etc.
Enter "c update" then Submit in the HostName field.
Login as "dts" pass "update"
Navigate to one or the other .bin files and Update.

In browser (me-no-dev):

https://github.com/espressif/arduino-esp32

Read: Instructions for board-manager.

https://github.com/espressif/arduino-esp32/blob/master/docs/arduino-ide/boards_manager.md

v1.04 is current release:

In File->Preferences, add one of below the additional board web-page:

https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_dev_index.json

Stable:

https://dl.espressif.com/dl/package_esp32_dev_index.json

// for esp8266:
https://arduino.esp8266.com/stable/package_esp8266com_index.json

---------------------------------------------------------------------------
To update via the USB cable:

If it doesn't exist, create folder C:\Users\Scott\Documents\Arduino\projects\OutputFiles
Edit C:\Users\Scott\AppData\Local\Arduino15\preferences.txt and add
build.path=C:\Users\Scott\Documents\Arduino\projects\OutputFiles

Turn on Verbose output during Upload in File->Preferences.

Use a tiny screwdriver or unfolded-paperclip to press
and hold the PGM button on the ESP32 Dev. Board (the button to the left is the RST
(reset) button). Open Arduino IDE and compile the program in the Arduino IDE via
Sketch->Upload.

After successful upload, copy the programming command used in the upload from
the Arduino IDE console-area: Copy the path by highlighting and Ctrl-C the path
then Ctrl-V paste it into the pgm.bat file...

Example: C:\Users\Scott\AppData\Local\Arduino15\packages\esp32\tools\esptool_py\3.3.0/esptool.exe --chip esp32 --port COM3 --baud 921600 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 80m --flash_size 4MB 0x1000 C:\Users\Scott\Documents\Arduino\projects\OutputFiles/DTS_SMART_FAN_CONTROLLER.ino.bootloader.bin 0x8000 C:\Users\Scott\Documents\Arduino\projects\OutputFiles/DTS_SMART_FAN_CONTROLLER.ino.partitions.bin 0xe000 C:\Users\Scott\AppData\Local\Arduino15\packages\esp32\hardware\esp32\2.0.3/tools/partitions/boot_app0.bin 0x10000 C:\Users\Scott\Documents\Arduino\projects\OutputFiles/DTS_SMART_FAN_CONTROLLER.ino.bin 
esptool.py v3.3

Now you are able to avoid using the "Upload" command (which forces recompillation every time!).
Open Arduino IDE and compile the program in the Arduino IDE via Sketch->Export Compiled Binary.
Double-click fixname.bat to rename the binary output file fc.bat.

Now you can upload the program to as many ESP32s as you want without recompiling:

To update via the USB cable, use a tiny screwdriver or unfolded-paperclip to press
and hold the PGM button on the ESP32 Dev. Board (the button to the left is the RST
(reset) button). Double-click the pgm.bat file you edited above to use the correct
file-path(s).

-------------------------------------------------------------------------------

To upload the web-interface pages that are in the Data folder:

Go to the spiffs folder and click fcspiffs.bat. Make sure the mkspiffs.exe program
is in the spiffs folder. Get it at: https://github.com/igrr/mkspiffs/releases

fcspiffs.bat works as-is for the Default partition scheme - Default 4MB with spiffs
(1.2MB APP, 1.5MB SPIFFS)

Run fcspiffs.bat to generate fc.spiffs.bin

Upload fc.spiffs.bin to your ESP32 board from the Arduino IDE via:
 Tools->ESP32 Sketch Data Upload.

If you don't have the command "ESP32 Sketch Data Upload" - you need to make the
folder C:\Program Files (x86)\Arduino\tools\ESP32FS\tool. And in it, put
esp32fs.jar

Get esp32fs.jar at: https://github.com/me-no-dev/arduino-esp32fs-plugin/releases

Contents of fcspiffs.bat:

@echo off
rem https://www.instructables.com/id/Set-Up-an-ESP8266-Automatic-Update-Server/
rem updater software arduino uses for data upload:
rem C:\Users\Scott\Documents\Arduino\hardware\espressif\esp32\libraries\Update\src
rem Once you have it, building the SPIFFS binary is simple. I have a one-line batch file
rem for the 1M version which takes the version number as a parameter (%1)
rem  THIS IS WORKING!!!! (S.S. 5/24/2020)
rem  This is for the Arduino ESP32 tools->partition scheme->Minimal SPIFFS(1.9MB APP with OTA 190KB SPIFFS)
rem  min_spiffs.csv in documents\arduino\hardware\espressif\esp32\tools\partitions
rem  offset: 0x3D0000, image size (-s): 0x30000,
rem  My fan-controller .ino arduino ESP32 sketch checks for "spiffs" in file-name
rem  then uses: Update.begin(SPIFFS.totalBytes(), U_SPIFFS)rem 
rem mkspiffs.exe -p 256 -b 4096 -s 0x30000 -c ..\data fc.spiffs.bin
mkspiffs.exe -p 256 -b 4096 -s 0x170000 -c ..\data fc.spiffs.bin
pause
-------------------------------------------------------------------------------


