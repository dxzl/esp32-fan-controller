ESP32FS adds an item to the old Arduino IDE Tools menu that will upload your SPIFFS data to an older ESP32 board.

ESP32S3FS adds an item to the old Arduino IDE Tools menu that will upload your SPIFFS data to a newer ESP32S3 board.

To install, create a folder called "tools" in your sketches folder and put the ESP32FS folder into it.

For example, on a Windows PC, if your sketches (programs) are in C:\Users\Me\Documents\Arduino\projects,
add the folder "tools" into C:\Users\Me\Documents\Arduino and unzip ESP32FS and ESP32S3FS into it. Restart your IDE and in the "Tools" menu there will be two new items, "ESP32 Sketch Data Upload" and "ESP32S3 Sketch Data Upload".

So your directory tree would then be: C:\Users\Me\Documents\Arduino\ESP32FS\tool\esp32fs.jar