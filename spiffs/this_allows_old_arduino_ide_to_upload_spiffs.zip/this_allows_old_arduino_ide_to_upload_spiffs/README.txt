This tool adds an item to the old Arduino IDE Tools menu that will upload your SPIFFS data.

To install, create a folder called "tools" in your sketches folder and put the ESP32FS folder into it.

For example, on a Windows PC, if your sketches (programs) are in C:\Users\Me\Documents\Arduino\,
add the folder "tools" and unzip ESP32FS into it.

So your directory tree would then be: C:\Users\Me\Documents\Arduino\ESP32FS\tool\esp32fs.jar